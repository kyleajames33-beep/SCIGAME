import MultiplayerGame from './_components/multiplayer-game'

export default function MultiplayerPage() {
  return <MultiplayerGame />
}
