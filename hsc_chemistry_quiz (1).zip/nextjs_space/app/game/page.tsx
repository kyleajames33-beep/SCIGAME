import QuizGame from './_components/quiz-game'

export default function GamePage() {
  return <QuizGame />
}
